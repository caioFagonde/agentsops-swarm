# AgentOps Swarm v4

SOTA multi-agent worktree orchestration with multi-tier model routing, smart context management, automatic course generation, and token budget tracking.

Designed for senior developers who want controlled high-throughput implementation without losing safety, traceability, or merge discipline — and without burning through API limits in 10 minutes.

## What's new in v4

**Multi-tier model routing** — Four tiers from free local models to Opus, each used only where it matters. Heavy models plan; lightweight models execute, scout, summarize, and generate courses.

**Smart context** — File fingerprinting, compressed signatures, and targeted grep replace full-codebase reads. Executors get exactly the context they need, nothing more.

**Auto course generation** — Every completed task produces a reveal.js slide + companion guide explaining what was done, improvement opportunities, and failure modes. Serve the course locally or share it.

**Cascade fallback** — When a model hits limits or fails, the system automatically downgrades: Sonnet → Haiku → Codex → Gemini Flash → local Ollama. No more manual retries.

**Token budget tracking** — Real-time cost tracking per tier, per role, per task. Automatic tier downgrades when approaching daily limits.

## Model tiers

| Tier | Models | Cost | Used for |
|------|--------|------|----------|
| t0-local | Ollama qwen3 1.7b/4b | Free | Summaries, file classification, simple scouts |
| t1-fast | Gemini 2.5 Flash, qwen3 8b+ | ~Free | Scouts, course generation, context prep |
| t2-mid | Claude Sonnet, Codex, Haiku | $$ | Task execution, repair, verification |
| t3-heavy | Claude Opus | $$$ | Strategic planning ONLY — never execution |

## Install

**Linux/macOS:**

```bash
./install.sh
export PATH="$HOME/.local/bin:$PATH"
agentops doctor
```

**With local model setup:**

```bash
AGENTOPS_SETUP_LOCAL=true ./install.sh
```

**Windows PowerShell:**

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
.\install.ps1
agentops doctor
```

**Prerequisites:**
- Python 3.10+
- git
- npm (for Claude Code and Codex CLI)
- Ollama (optional, for free local models) — https://ollama.ai
- Gemini API key (optional, for t1-fast) — https://aistudio.google.com/apikey

## Quick start

```bash
cd /path/to/project
agentops init --name my-project
agentops tui
```

## Planning (t3-heavy → Opus)

```bash
agentops plan --overview overview.md --tranches 4 --run --profile opus-planner --overwrite
agentops list
```

## Scouting (t1-fast → Flash/Ollama)

```bash
# Smart scout using lightweight models (no CLI claude needed)
agentops scout --tranche 1 --smart

# Traditional CLI-based scout
agentops scout --tranche 1 --profile haiku-scout
```

## Execution (t2-mid → Sonnet/Codex)

```bash
# Launch with automatic cascade fallback
agentops launch --tranche 1 --spawn --monitor --fallback cascade

# Launch with animated dashboards
agentops launch --tranche 1 --spawn --monitor --mode headless --permission workspace
```

## Merge

```bash
agentops collect
agentops merge --tranche 1 --auto-repair --repair-attempts 2
```

Rollback refs are created before every merge:

```bash
agentops rollback --list
agentops rollback --ref agentops/rollback/<name>
```

## Course generation

Every completed task automatically generates a reveal.js course module. You can also trigger it manually:

```bash
# Generate course for a specific task
agentops course generate --task <task-id>

# Generate summary course for an entire tranche
agentops course generate --tranche 1

# Use local models only (free)
agentops course generate --task <task-id> --local

# View generated course files
agentops course view

# Serve the course locally
agentops course serve --port 8080
```

## New CLI commands

```bash
agentops setup-models           # Interactive local model setup
agentops setup-models --full    # Pull all recommended models
agentops inspect <task-id>      # Show task state, diff, report, logs
agentops context <task-id>      # Preview smart context for a task
agentops doctor                 # Enhanced: checks all tiers, models, keys
```

## Smart context

Instead of reading the entire codebase, v4 builds targeted context bundles:

1. **File fingerprinting** — SHA256 hashes detect changes without reading content.
2. **Compressed signatures** — Python files become imports + function/class signatures. JS/Vue get equivalent treatment.
3. **Grep targeting** — Keywords from the task description find relevant files.
4. **Test inference** — Implementation files automatically include their test files.
5. **Token budgeting** — Context is truncated to fit the model's budget.

## Budget tracking

```bash
# View current budget status
agentops budget

# Budget is shown in TUI header
agentops tui
```

The budget system tracks cost per invocation across all tiers. When approaching limits, it automatically downgrades: t3 → t2 → t1 → t0. Daily limits reset at midnight; session limits reset after 6 hours of inactivity.

## TUI

```bash
agentops tui
```

The TUI provides: status overview, prompt paste/edit, planner DAG generation, launch selection, smart scouting, course generation, merge gates, inspect tasks, model setup, budget display, and more.

## Prompt input

```bash
agentops prompt task-id                # paste directly, end with EOF
agentops prompt task-id --file plan.md # from file
agentops prompt task-id --edit         # open in $EDITOR
```

## Examples folder

```bash
.agentops/examples/       # drop reference images, specs, data
agentops examples-index   # generate an index for agents to use
```

## Safety model

```
isolated worktree → smart context → report → tests/checks → sequential merge → rollback ref → optional repair → course
```

Path locks prevent merge conflicts. Rollback refs enable recovery. Reports and courses create an audit trail.

## Project structure

```
agentops_swarm/
  __init__.py        # version
  cli.py             # main CLI + TUI
  models.py          # multi-tier model routing + fallback
  context.py         # smart context management + fingerprinting
  course.py          # reveal.js course generation
  budget.py          # token budget tracking
templates/
  roles/             # role system prompts per profile
  frameworks/        # framework-specific guidance
  prompts/           # reusable prompt templates
  course/            # course generation templates
bin/
  agentops           # launcher script
```

## Environment variables

| Variable | Purpose | Default |
|----------|---------|---------|
| `GEMINI_API_KEY` | Gemini Flash API access | — |
| `GOOGLE_API_KEY` | Alternative Gemini key | — |
| `ANTHROPIC_API_KEY` | Claude API (if using direct API) | — |
| `AGENTOPS_HOME` | Override install location | `~/.local/share/agentops-swarm` |
| `AGENTOPS_PYTHON` | Python interpreter | `python3` |
| `AGENTOPS_SETUP_LOCAL` | Auto-install Ollama on install | `false` |
| `AGENTOPS_INSTALL_TOOLS` | Auto-install npm tools on install | `true` |
| `AGENTOPS_DAILY_LIMIT` | Daily token budget (USD) | `5.00` |
| `AGENTOPS_SESSION_LIMIT` | Session token budget (USD) | `2.00` |
